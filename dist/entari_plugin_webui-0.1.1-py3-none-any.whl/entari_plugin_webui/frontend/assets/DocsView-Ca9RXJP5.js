import{I as e,e as c,o}from"./index-D813liDI.js";const r={};function t(n,s){return o(),c("div")}const _=e(r,[["render",t]]);export{_ as default};
